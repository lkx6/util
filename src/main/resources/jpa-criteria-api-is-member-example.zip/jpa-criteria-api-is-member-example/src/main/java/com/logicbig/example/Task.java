package com.logicbig.example;

import javax.persistence.*;

@Entity
public class Task {
    @Id
    @GeneratedValue
    private long id;
    @Column(unique = true)
    private String description;
    private String supervisor;

    public Task() {
    }

    public Task(String description, String supervisor) {
        this.description = description;
        this.supervisor = supervisor;
    }

    public String getDescription() {
        return description;
    }


    public String getSupervisor() {
        return supervisor;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", supervisor='" + supervisor + '\'' +
                '}';
    }
}